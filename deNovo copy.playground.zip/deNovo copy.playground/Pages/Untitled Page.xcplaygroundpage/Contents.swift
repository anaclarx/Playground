//: A SpriteKit based Playground

import PlaygroundSupport
import SpriteKit

class GameScene: SKScene {
    override func didMove(to view: SKView) {
        // Get label node from scene and store it for use later
        let porta = SKSpriteNode(imageNamed: "porta.jpg")
        porta.size = CGSize(width: 640, height: 480)
        porta.position = CGPoint(x:0, y: 0)
        self.addChild(porta)
        let question = SKLabelNode(fontNamed: "Helvetica Neue UltraLight 32.")
        question.text = "What is behind that door?"
        question.fontSize = 35
        question.fontColor = SKColor.white
        question.position = CGPoint(x: 100, y: 150)
        self.addChild(question)
        
        
        
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
}

// Load the SKScene from 'GameScene.sks'
let sceneView = SKView(frame: CGRect(x:0 , y:0, width: 640, height: 480))
if let scene = GameScene(fileNamed: "GameScene") {
    // Set the scale mode to scale to fit the window
    scene.scaleMode = .aspectFill
    
    // Present the scene
    sceneView.presentScene(scene)
}

PlaygroundSupport.PlaygroundPage.current.liveView = sceneView
